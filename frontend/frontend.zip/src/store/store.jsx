import { configureStore } from '@reduxjs/toolkit'
import auth from './slice/authSlice'
import loader from "./slice/loaderSlice"

export default configureStore({
  reducer: {
    auth,
    loader,
  }
})