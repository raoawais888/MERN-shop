
import {BrowserRouter , Routes , Route} from "react-router-dom";
import Register from "./pages/admin/Register"
import Login from "./pages/admin/Login"
import Dashboard from "./pages/admin/Dashboard";
import Otp from "./pages/admin/Otp";
import Resetpassword from "./pages/admin/Resetpassword";
import Passwordchange from "./pages/admin/Passwordchange";
import 'react-toastify/dist/ReactToastify.css';
import "./App.css";
 import ProtectedRoute from "./middleware/ProtectedRoute";
 import Users from "./pages/admin/Users";

function App() {
  
   
   


  return (
    
   <>
           <BrowserRouter>
            <Routes>
                       
              <Route path="/register" element={<Register />} />
              <Route path="/login" element={<Login />} />
              <Route path="/otp" element={<Otp />} />
              <Route path="/reset" element={<Resetpassword />} />
              <Route path="/password_reset/:id/:expire" element={<Passwordchange/>} />

          <Route element={<ProtectedRoute/>}>

            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/users" element={<Users />} />
        
        </Route>

            </Routes>
           </BrowserRouter>
     
   </>
  )
}

export default App
